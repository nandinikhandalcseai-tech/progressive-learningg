@echo off
cd /d "%~dp0"
cd "progressive_learning_submission/project"
call run_project.bat
