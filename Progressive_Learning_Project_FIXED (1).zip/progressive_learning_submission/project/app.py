from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3, os
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "progressive-learning-demo-secret"
DB = os.path.join(os.path.dirname(__file__), "learning.db")

QUESTIONS = [
    ("DBMS","What is a primary key?","A key that uniquely identifies a record","A key used only for sorting","A duplicate field","A password","A",1),
    ("DBMS","Which SQL command retrieves data?","SELECT","INSERT","UPDATE","DELETE","A",1),
    ("DBMS","Which SQL clause filters rows?","WHERE","ORDER BY","GROUP BY","CREATE","A",1),
    ("DBMS","What does normalization mainly reduce?","Data redundancy","Network latency","CPU speed","File size only","A",2),
    ("DBMS","Which JOIN returns matching rows from both tables?","INNER JOIN","CROSS JOIN","FULL TEXT","SELF DELETE","A",2),
    ("DBMS","A foreign key primarily establishes what?","A relationship between tables","A backup","A password","A database server","A",2),
    ("DBMS","Which operation combines rows from related tables?","JOIN","DROP","TRUNCATE","COMMIT","A",3),
    ("DBMS","What is a correlated subquery?","A subquery that references the outer query","A query with no SELECT","A database backup","A type of index only","A",3),

    ("Python","Which keyword defines a function?","def","func","function","define","A",1),
    ("Python","Which data type is mutable?","list","tuple","string","integer","A",1),
    ("Python","What does len() return?","Number of items","Memory address","Data type","Last item","A",2),
    ("Python","Which structure stores key-value pairs?","dictionary","set","tuple","string","A",2),
    ("Python","What does list comprehension create?","A list","A database","A class only","A package","A",3),

    ("Operating Systems","Which component manages processes?","Operating system","Compiler","Browser","Database","A",1),
    ("Operating Systems","What is virtual memory?","Memory management using disk space","A CPU register","A file format","A network cable","A",2),
    ("Operating Systems","Which scheduling algorithm uses a time quantum?","Round Robin","FCFS only","SJF only","FIFO disk","A",2),
    ("Operating Systems","Deadlock requires how many Coffman conditions?","Four","One","Two","Six","A",3),

    ("Computer Networks","What does IP stand for?","Internet Protocol","Internal Program","Internet Process","Interface Port","A",1),
    ("Computer Networks","Which device forwards packets between networks?","Router","Keyboard","Compiler","Printer","A",1),
    ("Computer Networks","Which protocol is connection-oriented?","TCP","UDP","IP","ARP","A",2),
    ("Computer Networks","What is DNS used for?","Name resolution","File compression","CPU scheduling","Database normalization","A",2),
    ("Computer Networks","Which layer provides end-to-end transport?","Transport layer","Physical layer","Data link layer","Presentation layer","A",3),
]

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS attempts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        domain TEXT NOT NULL,
        level INTEGER NOT NULL,
        score INTEGER NOT NULL,
        total INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)
    count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    if count == 0:
        conn.execute("INSERT INTO users(name,email,password) VALUES(?,?,?)",
                     ("Demo Student","demo@example.com",generate_password_hash("demo123")))
    conn.commit()
    conn.close()

def current_user():
    if "user_id" not in session: return None
    return db().execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()

def domain_stats(uid):
    conn = db()
    rows = conn.execute("""
        SELECT domain, ROUND(AVG(score),1) avg_score, COUNT(*) attempts
        FROM attempts WHERE user_id=? GROUP BY domain
    """,(uid,)).fetchall()
    conn.close()
    stats = {r["domain"]: {"score": r["avg_score"], "attempts": r["attempts"]} for r in rows}
    # Include all project domains even before an attempt
    for d in ["DBMS","Python","Operating Systems","Computer Networks"]:
        stats.setdefault(d, {"score": None, "attempts": 0})
    return stats

def weak_domain(uid):
    stats = domain_stats(uid)
    attempted = [(d,v["score"]) for d,v in stats.items() if v["score"] is not None]
    if not attempted:
        return "DBMS"
    return min(attempted, key=lambda x:x[1])[0]

def recommended_level(uid, domain):
    conn = db()
    row = conn.execute("""
        SELECT level, score FROM attempts
        WHERE user_id=? AND domain=? ORDER BY id DESC LIMIT 1
    """,(uid,domain)).fetchone()
    conn.close()
    if not row: return 1
    return min(3, row["level"] + 1) if row["score"] >= 70 else row["level"]

@app.route("/")
def index():
    user = current_user()
    return redirect(url_for("dashboard")) if user else redirect(url_for("login"))

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        name,email,password = request.form["name"].strip(),request.form["email"].strip(),request.form["password"]
        if not name or not email or not password:
            flash("Please fill all fields.")
            return render_template("register.html")
        conn=db()
        try:
            cur=conn.execute("INSERT INTO users(name,email,password) VALUES(?,?,?)",
                             (name,email,generate_password_hash(password)))
            conn.commit(); session["user_id"]=cur.lastrowid
            return redirect(url_for("dashboard"))
        except sqlite3.IntegrityError:
            flash("Email already registered.")
        finally: conn.close()
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        email,password=request.form["email"].strip(),request.form["password"]
        user=db().execute("SELECT * FROM users WHERE email=?",(email,)).fetchone()
        if user and check_password_hash(user["password"],password):
            session["user_id"]=user["id"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
def dashboard():
    user=current_user()
    if not user: return redirect(url_for("login"))
    stats=domain_stats(user["id"])
    weak=weak_domain(user["id"])
    level=recommended_level(user["id"],weak)
    conn=db()
    history=conn.execute("SELECT * FROM attempts WHERE user_id=? ORDER BY id DESC LIMIT 8",(user["id"],)).fetchall()
    conn.close()
    return render_template("dashboard.html",user=user,stats=stats,weak=weak,level=level,history=history)

@app.route("/assessment")
def assessment():
    user=current_user()
    if not user: return redirect(url_for("login"))
    domain=request.args.get("domain") or weak_domain(user["id"])
    level=int(request.args.get("level") or recommended_level(user["id"],domain))
    conn=db()
    qs=conn.execute("SELECT * FROM questions WHERE domain=? AND level=? ORDER BY RANDOM() LIMIT 5",(domain,level)).fetchall()
    conn.close()
    return render_template("quiz.html",domain=domain,level=level,questions=qs)

@app.route("/submit", methods=["POST"])
def submit():
    user=current_user()
    if not user: return redirect(url_for("login"))
    domain=request.form["domain"]; level=int(request.form["level"])
    qids=request.form.getlist("qid")
    conn=db()
    score=0
    for qid in qids:
        q=conn.execute("SELECT answer FROM questions WHERE id=?",(qid,)).fetchone()
        if q and request.form.get("q_"+qid)==q["answer"]: score += 1
    total=len(qids)
    pct=round(score*100/total) if total else 0
    conn.execute("INSERT INTO attempts(user_id,domain,level,score,total) VALUES(?,?,?,?,?)",
                 (user["id"],domain,level,pct,total))
    conn.commit(); conn.close()
    return render_template("result.html",domain=domain,level=level,score=pct,
                           passed=pct>=70,next_level=min(3,level+1))

@app.route("/init")
def initialize():
    init_db()
    return "Database initialized. You can return to the login page."

# Create questions table and seed from QUESTIONS
def seed_questions():
    conn=db()
    conn.execute("""CREATE TABLE IF NOT EXISTS questions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        domain TEXT, question TEXT, option_a TEXT, option_b TEXT,
        option_c TEXT, option_d TEXT, answer TEXT, level INTEGER)""")
    if conn.execute("SELECT COUNT(*) FROM questions").fetchone()[0]==0:
        conn.executemany("""INSERT INTO questions
        (domain,question,option_a,option_b,option_c,option_d,answer,level)
        VALUES(?,?,?,?,?,?,?,?)""",QUESTIONS)
    conn.commit(); conn.close()

init_db()
seed_questions()

if __name__ == "__main__":
    app.run(debug=True)
