"""
ML recommendation component for the Progressive Learning project.
A small Decision Tree classifier is trained on synthetic/seeded examples
to recommend the next learning level from student performance features.
"""
from sklearn.tree import DecisionTreeClassifier
import numpy as np

X = np.array([
    [35, 1, 25, 3], [48, 1, 40, 3], [55, 2, 50, 2],
    [62, 2, 60, 2], [68, 2, 65, 2], [72, 2, 75, 1],
    [78, 3, 80, 1], [85, 3, 90, 1], [92, 3, 95, 1],
    [45, 1, 30, 4], [59, 2, 55, 3], [74, 3, 78, 1],
])
# Features: previous_score, attempts, average_time_percent, wrong_answers
# Target: recommended level
y = np.array([1,1,1,2,2,2,3,3,3,1,2,3])

model = DecisionTreeClassifier(max_depth=3, random_state=42)
model.fit(X, y)

def recommend_level(previous_score, attempts, average_time_percent, wrong_answers):
    features = np.array([[previous_score, attempts, average_time_percent, wrong_answers]])
    return int(model.predict(features)[0])

if __name__ == "__main__":
    print("Recommended level:", recommend_level(76, 2, 80, 1))
