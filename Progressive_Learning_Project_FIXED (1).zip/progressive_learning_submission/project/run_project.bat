@echo off
title Progressive Learning System
echo ==========================================
echo   Progressive Learning System
echo ==========================================
echo.
echo Checking Python...
python --version
if errorlevel 1 (
  echo.
  echo Python is not installed or not in PATH.
  echo Please install Python from https://www.python.org/downloads/
  pause
  exit /b 1
)
echo.
if not exist venv (
  echo Creating virtual environment...
  python -m venv venv
)
call venv\Scripts\activate.bat
echo.
echo Installing required packages...
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo Starting the application...
echo Open http://127.0.0.1:5000 in your browser.
echo Press CTRL+C to stop the server.
echo.
python app.py
pause
