# Adaptive Progressive Learning System

A B.Tech/BE minor project demo for "Progressive Learning in Weaker Domain".

## Features
- Student registration/login
- Four academic domains
- Initial/domain-wise assessment
- Automatic weaker-domain identification
- Progressive levels (1 Basic, 2 Intermediate, 3 Advanced)
- 70% progression threshold
- Performance history
- Dashboard and progress chart
- SQLite database
- Sample question bank

## Run on Windows

1. Install Python 3.10+.
2. Open Command Prompt in this project folder.
3. Create a virtual environment:
   `python -m venv venv`
4. Activate it:
   `venv\Scripts\activate`
5. Install dependencies:
   `pip install -r requirements.txt`
6. Run:
   `python app.py`
7. Open:
   `http://127.0.0.1:5000`

Demo account:
Email: demo@example.com
Password: demo123

The SQLite database `learning.db` is created automatically.

## Project structure

app.py
templates/
  base.html
  login.html
  register.html
  dashboard.html
  quiz.html
  result.html
static/
  style.css
requirements.txt
README.md

## Important
This is a minor-project prototype, not a production deployment. Flask's built-in development server is intended for local development/testing, not production use.
